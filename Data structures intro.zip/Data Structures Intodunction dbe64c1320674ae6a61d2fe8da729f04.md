# Data Structures Intodunction

- What are data structures ?
    - Data Structures are collection of values, the relationship between them, and the functions or operations that can be applied to the data. e.g arrays are a collection of values, the are ordered and have muliple built in methods.
- ES2015 class syntax Overview
    - What is a class ?
        - A blue print for creating objects or instantiating instances with pre-defined properties and methods.
    - How JavaScript implements the idea of classes ?
        - We use the class keyword, followed by the name of the class or identifier which uses CamelCase naming convention.
        - Inside the class we have a constructor function, which is used to instantiate new instances of that class, So when we create a new student using the constructor function, we provide it two properties firstName and lastName, and it assigns them to that object or instance.
        - To create a new instance we have to use the `new` keyword followed by the constructor function.
        
        ```jsx
        class Student {
        	constructor(firstName, lastName) {
        		this.firstName = firstName;
        		this.secondName = secondName;
        	}
        }
        
        let firstStudent = new Student("Haider", "Ali");
        let secondStudent = new Student("Mohammad", "Musa");
        ```
        
    - What are constructor Functions ?
        - Special functions that are run when a class is instanciated
    - What are instance methods in a class ?
        - Instance methods provide functionality that pertains(is applicable) to a single instance of a class, and can only be called through a class instance
        
        ```jsx
        class Student {
        	constructor(firstName, lastName) {
        		this.firstName = firstName;
        		this.secondName = secondName;
        	}
        	fullName() {
        		return "Your full name is ${this.firstName} ${this.lastName}";
        		// Here this is refering to the individual instance, e.g. whoever is
        		// calling this method the firstStudent instance or secondStudent 
        		// instance it's going to pertain to that instance only.
        	}
        }
        
        let firstStudent = new Student("Haider", "Ali");
        let secondStudent = new Student("Musa", "jani");
        firstName.fullName();// Haider Ali
        ```
        
    - What are static methods or class methods in a class ?
        - This allows us to define methods or functionalites that is pertinent to class but not necessarily to an individual instances of a class, it’s a utility(useful or benefical) function. To call a static method we use the class name and dot notation to invoke it.
        
        ```jsx
        class Student {
        	constructor(firstName, lastName) {
        		this.firstName = firstName;
        		this.secondName = secondName;
        	}
        	fullName() {
        		return "Your full name is ${this.firstName} ${this.lastName}";
        		// Here this is refering to the individual instance, e.g. whoever is
        		// calling this method the firstStudent instance or secondStudent 
        		// instance it's going to pertain to that instance only.
        	}
        	static enrollStudent(...students) {
        		// maybe send an email here
        		return "Enrolling Student";
        	}
        }
        
        let firstStudent = new Student("Haider", "Ali");
        let secondStudent = new Student("Musa", "jani");
        firstName.fullName();// Haider Ali
        
        Student.enrollStudent([firstName, secondName]);
        ```
        
    - What does the `this` keyword mean ?
        - The meaing of `this` keyword changes depending on it’s context. When we are inside of a constructor `this` refers to the individual instance of that class, e.g. if the student we are taking about is `firstStudent` then `this` refers to the `firstStudent` instance or  `firstStudent` object that we created.