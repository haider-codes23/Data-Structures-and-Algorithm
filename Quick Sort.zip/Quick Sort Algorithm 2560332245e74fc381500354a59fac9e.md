# Quick Sort Algorithm

- What is quick sort algorithm ?
    - It work like merge sort
    - We keep splitting up the array until we have sub arrays that have 0 or 1 element each
    - It takes advantage of the fact that arrays with 1 or 0 element are always sorted
    - It works by selecting one element which we call the `pivot` and finding the index where the `pivot` should end up in the sorted array. e.g. if the element that we select as `pivot` is the first element in the array, so what we are going to do is move all the numbers that are lower than `pivot` element to the left of the `pivot` and all the number that are greater than `pivot` to the right. We are not going to sort them all, we are just going to moving some of them to oneside and others to the other side, and from there we will know that one number e.g. `pivot` is in the correct spot.
    - Once the pivot is positioned appropriately, we can repeat the process for the left side and the right side.

![Screenshot from 2024-04-15 15-48-52.png](Quick%20Sort%20Algorithm%202560332245e74fc381500354a59fac9e/Screenshot_from_2024-04-15_15-48-52.png)

- Whats the psuedocode for quick sort ?
    - Declare a function called quickSort() that takes a start index, end index and an array as argument, and this function is going to be a recursive function. The start index is going to have a default value of 0 and the end Index is going to have a default value of length-1.
    - Like every recursive function has a base case, here the base case is going to be if the startIndex is less than the endIndex repeat the process e.g. when quickSort is called for the first time, we pass it an array, a startIndex and an endIndex, the startIndex is at 0 and the endIndex index of the last element in the array. So the first time this base case evaluates as true, then pivot helper function is called which places the pivot element in it’s sorted postion and returns us the index of the pivot, we use that pivotIndex to recursively call quickSort() on the left side and right side of the pivot, each time we recursively call the quickSort() function the difference between the startIndex and leftIndex decreases by one, and when the startIndex and endIndex are both equal to 0 that would mean that all the elements have been sorted, at that moment this would evalute as false and we would return the sorted array.
    - Then we would call the pivot helper function and pass it the array, startIndex and endIndex
        - Inside the pivot helper function it’s going to grab the element at the startIndex and store it in a variable called pivot.
        - Then we will create a variable called swap index and assign it the index of pivot element which is the start index, it keeps track of where we are going to swap our pivot element e.g. when we loop over the array and encounter an element less than pivot element we will increment pivot index by 1 and when the loop has finished executing we will swap our pivot element with the element at swapIndex, this way all the elements less than pivot element will be on the left side of the pivot element and all the elements greater than pivot element will be on the right side of pivot element.
        - Next we need to loop over the items in the array except the one at startIndex becasue that is our pivot element and we need to kee looping until we have reached the endIndex
        - Inside the loop we check if the element at the current index is less than the pivot element
        - if any element is less than the pivot element we will increment the swapIndex by 1 and swap the element at the swapIndex with the element at curretnt index .g. arr[i]
        - if the element at the current index is greater than pivot element we will do nothing.
        - when the loop has finished executing we will swap our pivot element with the element at pivotIndex, this way all the elements less than pivot element will be on the left side of the pivot element and all the elements greater than pivot element will be on the right side of pivot element.
        - In the end we will return the index of the pivot element.
        - We will store the index of the pivot element in a variable called pivotIndex
        - Then we will recursively call the quickSort function on the left side of the pivot, so we will pass it the whole array, startIndex which is 0 and endIndex which is going to be one index less than pivot index
        - Then we will recursively call the quickSort function on the right side of the pivot, so we pass it the array, the startIndex which is going to be an index 1 greater than the pivotIndex and the endIndex is going to be the length of the array -1.