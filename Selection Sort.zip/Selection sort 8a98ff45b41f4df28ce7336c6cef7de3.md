# Selection sort

- What is Selection sort ?
    - In bubble sort the largest value bubbles up to the top one at a time. We started from the beginning till the end and accumilated at the end
    - In selection sort it places small values into sorted position. We are still going from the beginning till the end but we will be accumilating at the beginning e.g. we will be sorting smaller values first.
    - lets say we have an array `[5, 3, 4, 1, 2]` . We start at the beginning, we are going to go all the way through the array looking for the minimum value and we are going to put that at the front. e.g. we start with 5 and 3 here 3 is smaller, so 3 is going to be our minimum for now. Then we compare our minumum e.g. 3 and 4, 3 still the minimum, then we compare our minimum with 1, here 1 is minimum, so now our minimum is 1. Then we compare our new minimum e.g. 1 with 2, here 1 still is our minimum. Now when we hit the end of the array we take our minimum and swap it with it the element with which we started with e.g. we started with 5. And now we have put the smallest item in the array in the beginning

```jsx
function selectionSort (arr) {
  for (let i = 0; i < arr.length - 1; i++) {
    let minimum = i;
    for (let j = minimum; j < arr.length - 1; j++) {
      console.log("Before: ",arr, arr[j + 1], arr[minimum])
      if (arr[j + 1] < arr[minimum]) {
        minimum = j + 1;
      }
      

    }
    console.log(`${i + 1} pass done`);
    if (arr[minimum] !== arr[i]) {
      [arr[i], arr[minimum]] = [arr[minimum], arr[i]];
    }
    console.log("After swaping: ",arr)
    console.log("******************************************")

  }
  return arr;
}
console.log(selectionSort([5, 3, 4, 1, 2]));
```

- Whats the pseudocode for selection sort ?
    - create an outer loop that starts from i = 0 to less than the length of the array - 1, it’s purpose is to set the minimum to i which is the i-th iteration it is execting and to execute the inner loop one less time than the number of elements in the array. E.g. the inner loop does all the comparisons, and if we were to execute as many times as the number of element in the array in the last iteration of the inner loop we will be comparing the last element with undefined which is unnecessary.
        - create a variable called minimum which is going to store the value of i which is the i-th iteration the outer loop is executing, e.g. when the outer loop has executed once i will be equal to 1, minumum will be set to 1 as well, and our inner loop will start iterating from j = 1 instead of j = 0, that way it wont iterate over the first element becasue it had already been sorted in the previous execution of the inner loop.
    - create an inner loop which goes from j = minimum to less than the length of the array - 1, it’s purpose is to sort the smallest number in the array one at a time. Each time the inner loop begins it has one less element to iterate over e.g. the element it sorted in the previous execution of inner loop, it doesn’t have to iterate over them.
        - inside the loop we check if the value at the index next to the one we are iterating over is less than the value we are currently iterating over, if it is we assign minimum with the index of the value next to the one we are iterating over. and we keep doing this till the last element in the array.
    - When an execution of the inner loop has finished we would check if the value at minimum  index is the same as the value we began iterating with  e.g. in the first execution it will be the element at index 0, in the second execution it will be the element at the index 1 and so on. If it is not we will swap the value at minimum index with the value at the index with which we began with.
    - In the end we return the sorted array
    
- Whats the Big O of selection sort ?
    - Time complexity in worst case is O(N^2)

- Why is selection sort better than bubble sort ?
    - In selection sort we are comparing item but only making one swap at the end of each loop, but in bubble sort we are comparing and making multiple swaps with in an exection of a loop.