# Doubly Linked List

- What is a Doubly linked list ?
    - A data structure, that is ordered, can store any kind of data, contains a head, a tail and also has length property.
    - The head is the first node in the doubly linked list and the tail is the last node in the doubly linked list
    - Doubly Linked list consists of nodes, each node contains a value, apointer to the previous node which we call `prev` and a pointer to the next node which we call the `next`
    - Each node is connected two directionally to the next node and the previous node

## Push intance method

- What does the push() intance method do and how to implement it ?
    - It removes a Node from the end of the list
    - Create a function called push(val), that takes a value as an argument
    - Then create a new node using the constructor function and pass it the val as argument
    - Then check if the list is not empty, if the list is empty make the head and tail property point at the newNode
    - Else assign the next property of tail to point towards the new node, the previous property of new node to point towards the tail and at last set the tail property to point towards the new node.
    - increment the length by 1
    - return the list

## Pop instance method

- What does the pop() instance method do and how to implement it ?
    - It removes the last node in the list
    - create a function called pop()
    - Firstly check if the list is not empty, if it is return undefined
    - Then create a variable called poppedNode and assign it the tail node
    - In case there is only one node in the list check if the length of the list is equal to 1, if it is assign both the head and tail node null value.
    - Else set the tail property to PoppedNode’s previous pointer
    - Then set the tail property’s next to null
    - Then set the Popped Nodes previous to null
    - Then decrement by 1
    - return the popped node
    

## Shift instance method

- What does the shift instance method do and how to implement it ?
    - It removes the first node in the list
    - Firstly check if the length of the list is 0, if it is then return undefined
    - Then create a variable called removedNode and store the current head in it
    - Then check if the length of the list is equal to 1, if it is then set both the head and tail equal to null
    - Else update the head to point towards the next of removed node
    - Then set the next of removesNode to null
    - Then set the previous of new head to null
    - Then decrement the length by 1
    - And return the removed node

## Unshift instance method

- What does the unShift method do and how to implement it ?
    - It add a node at the beginning of the list
    - Create a new node and pass it the value passed to the unshift(val) method
    - Then check if the length of the list is 0, if it is then assign the head and tail to point towards the new node
    - else store the head in a variable called old head
    - set the head to point towards the newNode
    - set the next property of newNode to point towards the oldHead
    - set the oldHeads previous property to point towards new head or new node
    - increment the length by 1
    - and return the list

## Get instance method

- What does the get method do and how is it implemented ?
    - It returns us a node at a specifc index
    - Firstly we will check if the index provided is less than the 0 or greater than or equal to the length of the list, if it is return null.
    - Then calculate the midpoint by dividing the lenght - 1 by 2
    - Then declare two variables called counter and current
    - If the index provided is less than midpoint then
        - set the counter to 0
        - set current to the head node
        - create a loop that goes on until counter is less than index
            - set the current to next of current
            - increment counter by 1
    - Else if the the index is greater than midpoint then
        - set the counter to length - 1
        - set the current to tail node
        - create a loop that goes on until counter is greater than provided index
            - set the current to prev of current
            - decrement counter by 1
    - return current

## Set instance method

- What does the set instance method do and how to implement it ?
    - It replaces the value of specific node in the list.
    - create a function called set that takes two arguments called value and index
    - Firstly check if the index provided is less than 0 or greater than or equal to the lenght of the list, if it is return null
    - Then calculate the midPoint by dividing the length - 1 by 2
    - Then declare two variables called counter and current
    - If the index is less than midpoint then
        - set the counter to 0
        - set current to point towards the head node
        - create a loop that goes on until counter is less than index
            - inside the loop set current to next of current
            - increment counter by 1
        - Set the current node’s val to the value provided as arg
        - return true
    - Else if index is greater than midpoint
        - set the counter to length - 1
        - set current to point towards the tail node
        - create a loop that goes on until counter is greater than index
            - set the current to prev of current
            - decremenet counter by 1
        - Set the current node’s val to the value provided as arg
        - return true
    - otherwise return false
    

## insert instance method

- What does the insert method do and how to implement it ?
    - It inserts a node at a specified index in the list
    - create a new node with the value given as argument
    - use the get method to get the node at the specific index
    - create a variable called before node and set it the prev of current Node
    - set the next of newNode to next of beforeNode
    - set the prev of currentNode to newNode
    - set the next of before node to newNode
    - set the prev of newNode to beforeNode
    - return the list

## Remove instance method

- What does the remove method do and how to implement it ?
    - Firstly check if the index provided is less than 0 or equal to or greater than the length of list, if it is return null
    - Then check if the index provided is equal to 0, if it is use shift() method
    - Then check if the index provided is one less than the length of the array, if it is use pop() method
    - Then declare a variable called nodeToRemove and set it the the return value of get(index)
    - Then declare a variable called beforeNode and set it to the prev of nodeToRemove
    - Then declare a variable called afterNode and set it to the next of nodeToRemove
    - Then set the next property of beforeNode to afterNode
    - Then set the prev propery of afterNode to beforeNode.
    - At last set the next and prev property on nodeToRemove to null
    - decerement by 1
    - return NodeToRemove;

## Reverse a linked list

- How to reverse a linked list and how to implement it ?
    - Firstly check if the list is not empty
    - Then create a variable called current and and set it to the head node
    - Then make the head point at the tail
    - Then make the tail point at the head
    - Then create a loop that goes on until i is less than the length of the list
        - inside the loop create a variable called prev and assign it the previous of the current node
        - inside the loop create a variable called next and assign it the next of the current node
        - Then assign the previous of current the next of the current
        - Then assign the next of current previous of current
    - return the list

- Whats the Big O of Doubly linked List ?
    - Insertion has a time complexity of O(1)
    - Removal has time complexity if O(1)
    - Searching has a time complexity of O(n)
    - Accessing has a time complexity of O(n)
    - 
-