# Searching Algorithms

```jsx
let usernames = ["haider", "Musa", "Ibraheem", "Yusuf", "Ali"];
// Now if we want to check for the existance of some username or search in the array above
// we can use indexOf() methods that either returns the index of the element or 
// -1 if the element doesn't exist. 
// In this lesson we will try to implement our own searching algorithms 
```

# Objectives

1. Describe what a searching algorithm is 
2. Implement linear search on arrays 
3. Implement binary search on sorted arrays 
4. Implement a naive string searching algorithm 
5. Implement the KMP string searching algorithm

## linear Search

- What the simplest way to search ?
    - Given an array, the simplest way to search for a value is to look at every element in the array and check if it’s the value we want. This is called linear search.

```jsx
function linearSearch (arr, val) {
  for(let i = 0; i < arr.length; i++) {
    if (arr[i] === val) {              
      return i;
    }
    
  }
  return -1;
} 
// Whats the time complexity of this algorithm ?
// The time complexity is the the lenght of the loop, so the best case sceniro is O(1) e.g if the element we are looking for is the first element 
// but the worst case sceniro is O(N) that is as the numbers of elements in the array increase the number of operation will increase thus the runtime will increase
console.log(linearSearch([1, 2, 3, 4, 4, 7, 56, 87, 76], 87));
```

## Binary Search

- Whats the difference between linerar search and binary search  ?
    - Binary serach is much faster than linear search. In linear serach we check each element one by one to find out if the element we are looking for exists, so we eliminate one element at a time. In binary search we can eliminate half of the elements but it only works with sorted arrays.
    - Binary serach works alot like divide and conquer algortihm, we divide the array into half and check the last element of the first half if it’s less than or greater than the element we are looking for, if it is less than the element we are looking for we can ignore the firt half becasue our element doesn’t exists in that first half. Then we will take the second half of the array and divide it again. We will check the last element of the first half, if it’s less than or greater than the element  we are looking for, if its greater than the element we are looking for then that means the element we are looking for exist in the half.
- Whats the pseudocode for binary search ?
    - declare a function called binary search that takes a sorted array as argument
    - declare three variables called leftPointer, middlePointer and RightPointer. These pointers will hold the index or position of element, not the actual values.
    - The left pointer will point at the left most index in the array, the right pointer will point at the right most index in the array and the middle pointer will point at the index which is the average of the left pointer and right pointer.
    - Then loop over the array as long as the left pointer is less than or equal to the right pointer
        - Then check if the value at middle pointer is less than or greater than or equal to the value we are looking for, if it’s equal to the value we are looking for return the value of middle pointer(index), if it’s less than the value we are looking for ignore the first half(move the left pointer to one index to the right of the middle pointer and reassign middle pointer e.g. the average of left pointer and right pointer), if the value at the middle pointer is greater than ignore the second half(move the right pointer to one index less than middle pointer and reassign the middle pointer e.g. the average of left pounter and right pointer). Repeat this process until you find the value your looking for.
        - and if the value we are looking for cannot be found return -1