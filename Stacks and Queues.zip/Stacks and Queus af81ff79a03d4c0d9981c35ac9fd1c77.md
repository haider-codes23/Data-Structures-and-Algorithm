# Stacks and Queus

## Stacks

- What is a stack  where are they used and how to implement it?
    - It’s an abstract(existing in thought or as an idea) data structure, and it abides by LIFO, that is last element added to the stack will be the first element removed from the stack or **Last in First Out .**
    - Every programming language uses a data structure that manages what happens when function are invoked. When functions are invoked they might be waiting on other functions to return e.g if we have a function called first and with in that we have a second function that get invoked, so we want them to go in the right order, and the data strucutre reponsible for that is called call stack.
    - To implement it we can use built in data structures like array or we could use a linked link
    
    ```jsx
    // implementing stacks using arrays
    let stack = [];
    
    // In order for array to act like a stack we need a way to add to it, so that the first item added can only be removed in the end 
    stack.push("MY");
    stack.push("Name");
    stack.push("is");
    stack.push("Musa Jani");
    
    // Inorder for this to be a stack we need a way to remove from it where the most recently added thing what i get first when i remove something from it
    // The built in method of array e.g. pop() can do that for us
    console.log(stack.pop());
    console.log(stack);
    ```
    

- How to implement push method in stacks using linked list
    - create a new node using the value passed to the push method
    - check if the list has any nodes in it, if empty point the head and tail to the newly created node
    - else create a variable called current and store the current head in it.
    - set the new node to become the new head or move head one ahead
    - set the next property of newNode or new head to current this way the new node added hold a pointer to the previous node
    - incremenet length by 1
    - return the new length

- How to implement pop method in stack using linked list ?
    - check if the list is not empty, if it is return null
    - store the head in a variable called nodeToBeRemoved
    - if the list only contains one node e.g. `if (this.head === this.tail)` or `this.length === 1` in that case make the head and the tail equal to null
    - Else set the head to next of the nodeToBeRemoved.
    - decrement length by 1
    - return the removed node
    
- What the Big O of stacks ?
    - Insertion has a time complexity O(1)
    - removal has a time complexity of O(1)
    - Searching has a time complexity of O(n), becasue we have to traverse the entire stack.
    - Accessing has a time complexity of O(n) becasue we have to traverse through the entire stack to get the value we want

## Queues

- What are queues and how to implement it  ?
    - It’s an abstract data structure, that abides by FIFO, meaning First In First Out or the First element added to the queue wil be the first element removed.
    - We can implement it using arrays and linked list as well.
    - To add something in a que we will use enQue and to remove from a que we use deQue
    
    ```jsx
    let queue = [];
    
    // add to the end of a queue [1, 2, 3, 4, 5] the first element added was 1
    // then 2 then 3 then 4 then 5 
    queue.push(1);
    queue.push(2);
    queue.push(3);
    queue.push(4);
    queue.push(5);
    
    // so when removing from we need to abide by the FIFO principle e.g. First 
    //In First Out so we need to remove from the beginning
    // if we used the pop method we would be removing the last element added first,
    // we dont want to do that, instead we would use shift method
    // which removes the first element from the array
    // Using shift() method has a draw back we are removing from the beginning which 
    //requires reindexing all the element in the array which increases the
    // time complexity and is very inefficient as well
    // console.log(queue.unshift());
    
    // Another way to implement a Queue is to use unshift for adding elements e.g.
    // we will be adding elements to the beginning 
    
    let anotherQueue = [];
    anotherQueue.unshift(1);
    anotherQueue.unshift(2);
    anotherQueue.unshift(3);[3, 2, 1] // Now the element is added to the beginning 
    //and each time an element is added all the elements require reindexing which 
    // again is inefficient
    
    // Now the first element added has been moved to the end of the array so the remove
    // we need to remove we have to start removing from the end for which we 
    // use pop() method 
    console.log(anotherQueue);
    
    ```
    

- Implementing enqueue and dequeue Queues using Linked List !!
    - How to implement enqueue
        - Firstly we’ll create a newNode and initialize it with the value passes to the enqueue method
        - Then we’ll check if the list has any node in it if not we will point both head and tail towards this new node
        - Else we need to add the node at the end of the list for that we will set the next property of tail to point towards the newNode and then set the tail to point towards the newNode
        - increment length by 1
        - return the length
    
    - How to implement dequeue
        - We remove from the beginning of the list
        - Firstly check if the queue has any nodes, if not then return null
        - then store the current head in a variable called oldHead
        - set the next of oldHead to become the new head
        - set the next property of oldHead to null
        - decrement lenght by 1
        - return the oldHead
    
    ```jsx
    class Node {
      constructor(val) {
        this.val = val;
        this.next = null;
      }
    }
    
    class Queue {
      constructor() {
        this.head = null;
        this.tail = null;
        this.length = 0;
      }
      // implementing EnQueue for adding something in Queue or it will add at the very end of the list
      enqueue (val) {
        let newNode = new Node(val);
        if (!this.head) {
          this.head = newNode;
          this.tail = newNode;
        } else {
          this.tail.next = newNode;
          this.tail = newNode;
        }
        this.length++;
        return this.length;
      }
      // implementing DeQueue for removing first thing that was added in in Queue
      dequeue () {
        if (!this.head) return null;
        let oldHead = this.head;
        if (this.length === 1) {
          this.head = null;
          this.tail = null;
        } else {
          this.head = oldHead.next;
          oldHead.next = null;
        }
        this.length--;
        return oldHead.val;
      }
    
    }
    
    let queue = new Queue();
    
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    queue.enqueue(4);
    
    console.log(queue);
    console.log("********************");
    console.log(queue.dequeue());
    console.log(queue.dequeue());
    console.log(queue.dequeue());
    console.log(queue.dequeue());
    console.log(queue.dequeue());
    ```
    
    - What the Big O of stacks and Queues when implemeted using linked list ?
        - Enqueue and dequeue in queues using linked list is constant time O(n).
    -