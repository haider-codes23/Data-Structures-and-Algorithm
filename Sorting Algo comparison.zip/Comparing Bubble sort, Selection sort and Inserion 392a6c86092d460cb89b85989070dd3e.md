# Comparing Bubble sort, Selection sort and Inserion sort

![Screenshot from 2024-03-31 01-43-29.png](Comparing%20Bubble%20sort,%20Selection%20sort%20and%20Inserion%20392a6c86092d460cb89b85989070dd3e/Screenshot_from_2024-03-31_01-43-29.png)

- Whats the time complexity of Bubble Sort Algorithm ?
    - In worst and average case the time complexity is O(n^2) becasue we have a nested loop and we are rougly making `n` number of comparison for each item in the array e.g. `[8, 3, 2, 1, 4]` inorder to sort `8` to the end of the array we will have to compare 8 with each item in the array.
    - In best case e.g. if we get an almost sorted array or a fully sorted array the time complexity is O(n).
    
- Whats the time complexity for selection sort ?
    - We are rougly comparing each element with every other element in the array so as the number of element scale the number of comparsion scale at the rate of n * n. So the worst, average and best case is O(n^2).
    - The only scenrio where selection sort is better than bubble sort is when you want to minimize the number of sorts your making.
    
- Whats the time complexity of Insertion sort ?
    - It’s time complexity is similar to bubble sort and selection sort. As the length of array grows we have to make n^2 number of comparsions. But in case we get an amost sorted array the time compexity becomesO(n).
-