# Insertion sort

- What is insertion sort ?
    - It builds up a sorted array by gradually creating a larger left portion which is always sorted. Instead of finding the largest element one at a time or the smallest element one at a time, it takes each element and inserts it where it should go in the sorted half
    
    ![Screenshot from 2024-03-27 02-28-03.png](Insertion%20sort%205a89af0b3cb041b2b126d901469571f2/Screenshot_from_2024-03-27_02-28-03.png)
    
- Whats the pseudocode for Insertion sort ?
    - We create an outer loop that starts from i = 0 to less than the length of the array - 1, the outer loop will execute one less time than the number of elements in the array.
        - Then we create our inner loop that starts from j = i + 1 and loop until j is greater than 0 and we keep decrementing j after each iteration, here j will always point towards the element next to the sorted half e.g. during it’s first iteration j points at the 2nd element in the array at index 1 like wise during the second iteration it points at the 3rd element which is at index 2.
        - Inside the loop we will we check if the element at index j greater than the j - 1 if it is we break out of the inner loop, but if the element at index j is less than the element at index j - 1, we swap them and keep doing this till j > 0.
        - In the end we will return the array.
        
- Whats the time complexity ?
    - worst case is O(N^2) as the length of the array grows we also have to make n^2 number of comparisons but if our data is almost sorted it has time complexity of O(n)